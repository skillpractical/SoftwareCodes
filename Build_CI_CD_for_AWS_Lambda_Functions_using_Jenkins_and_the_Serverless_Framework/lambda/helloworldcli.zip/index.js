exports.handler = function (event, context) {
	context.succeed('Welcome to demo on AWS serverless deployments from cli.!!');
};